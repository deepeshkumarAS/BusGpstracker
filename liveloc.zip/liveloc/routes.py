

DATA = [
   {
     "stop_latitude":13.08728,
     "stop_longitude":80.1969568,
     "stop_name": "Thirumangalam"
   },

   {
     "stop_latitude":12.9929,
     "stop_longitude":80.1896,
     "stop_name": "CPWD Quarters"
   },

   {
     "stop_latitude":13.0719,
     "stop_longitude":80.2028,
     "stop_name": "Goldmine Hotel"
   },
   
   {
     "stop_latitude":13.0680,
     "stop_longitude":80.2059,
     "stop_name": "CMBT Park"
   },

   {
     "stop_latitude":13.0665,
     "stop_longitude":80.2147,
     "stop_name": "MMDA"
   },

   {
     "stop_latitude":13.103529,
     "stop_longitude":80.1975683,
     "stop_name": "Tirunagar"
   },

   {
     "stop_latitude":13.0373,
     "stop_longitude":80.2123,
     "stop_name": "Ashok Pillar"
   },
   
   {
     "stop_latitude": 13.0294896,
     "stop_longitude": 80.2062817,
     "stop_name": "Kasi Theater"
   },

   {
     "stop_latitude": 13.0225,
     "stop_longitude": 80.2032,
     "stop_name": "Ekkatuthangal"
   },
 
   {
     "stop_latitude": 13.052773,
     "stop_longitude": 80.2074983,
     "stop_name": "National School"
   },

   {
     "stop_latitude": 12.7524,
     "stop_longitude": 80.1918,
     "stop_name": "Shiv Nadar University Chennai"
   },
   
]


def get_routes_data():
    return DATA